package onion.pickle;  /* /nodynamiccopyright/ */
public class Mangle {  // hard coded linenumbers - DO NOT CHANGE
    public static void main(String args[]) {
                System.out.println("four");
                System.out.println("five");
                System.out.println("six");
                System.out.println("seven");
                System.out.println("eight");
                System.out.println("nine");
                System.out.println("ten");
    }
}
