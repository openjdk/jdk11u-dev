/* /nodynamiccopyright/ */ public class HelloWorld {  // hard coded linenumbers - DO NOT CHANGE
    public static void main(String args[]) {
        System.out.println("Hello, world!");
    }
}
