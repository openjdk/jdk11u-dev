/* /nodynamiccopyright/ hard coded linenumbers - DO NOT CHANGE */
class RedefineSubTarg {
    String foo(String prev) {
        return prev + "Boring ";
    }
}
